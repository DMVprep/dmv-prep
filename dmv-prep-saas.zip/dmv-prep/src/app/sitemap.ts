// src/app/sitemap.ts
import { MetadataRoute } from "next";
import { US_STATES, stateToSlug } from "@/data/states";

const BASE_URL = "https://dmvprep.pro";

const STATE_PAGE_TYPES = [
  "dmv-practice-test",
  "road-sign-practice-test",
  "permit-test-questions",
  "dmv-handbook-summary",
  "dmv-test-in-english",
  "dmv-test-tips",
];

export default function sitemap(): MetadataRoute.Sitemap {
  const staticPages: MetadataRoute.Sitemap = [
    { url: BASE_URL, changeFrequency: "weekly", priority: 1 },
    { url: `${BASE_URL}/states`, changeFrequency: "monthly", priority: 0.9 },
    { url: `${BASE_URL}/pricing`, changeFrequency: "monthly", priority: 0.8 },
    { url: `${BASE_URL}/register`, changeFrequency: "monthly", priority: 0.7 },
    { url: `${BASE_URL}/login`, changeFrequency: "monthly", priority: 0.6 },
  ];

  const statePages: MetadataRoute.Sitemap = US_STATES.flatMap((state) =>
    STATE_PAGE_TYPES.map((type) => ({
      url: `${BASE_URL}/state/${stateToSlug(state.name)}/${type}`,
      changeFrequency: "weekly" as const,
      priority: 0.85,
      lastModified: new Date(),
    }))
  );

  return [...staticPages, ...statePages];
}
