// src/app/dashboard/page.tsx
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Header } from "@/components/layout/Header";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import {
  BookOpen, Trophy, Clock, TrendingUp, Star, ArrowRight, BarChart2, Zap
} from "lucide-react";
import { US_STATES, stateToSlug } from "@/data/states";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login?callbackUrl=/dashboard");

  const user = await prisma.user.findUnique({
    where: { id: (session.user as any).id },
    include: {
      testSessions: {
        orderBy: { createdAt: "desc" },
        take: 10,
        include: { state: true },
      },
    },
  });

  const sessions = user?.testSessions ?? [];
  const totalTests = sessions.length;
  const avgScore = totalTests
    ? Math.round(sessions.reduce((s, ts) => s + (ts.score ?? 0) / ts.totalQ * 100, 0) / totalTests)
    : 0;
  const isPremium = user?.plan === "PREMIUM";

  const popularStates = US_STATES.slice(0, 6);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Welcome */}
        <div className="mb-8">
          <h1 className="text-2xl font-extrabold text-gray-900">
            Welcome back, {session.user?.name?.split(" ")[0] ?? "there"}! 👋
          </h1>
          <p className="text-gray-500 mt-1">Ready to practice? Let's keep your streak going.</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: BookOpen, label: "Tests Taken", value: totalTests, color: "text-blue-600 bg-blue-50" },
            { icon: Trophy, label: "Avg. Score", value: `${avgScore}%`, color: "text-yellow-600 bg-yellow-50" },
            { icon: TrendingUp, label: "Readiness", value: avgScore >= 80 ? "Ready!" : `${avgScore}%`, color: "text-green-600 bg-green-50" },
            { icon: Star, label: "Plan", value: isPremium ? "Premium" : "Free", color: "text-purple-600 bg-purple-50" },
          ].map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="card p-5">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-2xl font-extrabold text-gray-900">{value}</div>
              <div className="text-xs text-gray-400 mt-0.5 font-medium uppercase tracking-wide">{label}</div>
            </div>
          ))}
        </div>

        {/* Readiness bar */}
        {totalTests > 0 && (
          <div className="card p-6 mb-8">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="font-bold text-gray-900">Readiness Score</h3>
                <p className="text-sm text-gray-500">Based on your last {Math.min(totalTests, 5)} tests</p>
              </div>
              <span className={`text-2xl font-extrabold ${avgScore >= 80 ? "text-green-600" : avgScore >= 60 ? "text-yellow-600" : "text-red-500"}`}>
                {avgScore}%
              </span>
            </div>
            <div className="h-3 bg-gray-100 rounded-full">
              <div
                className={`h-3 rounded-full transition-all ${avgScore >= 80 ? "bg-green-500" : avgScore >= 60 ? "bg-yellow-500" : "bg-red-400"}`}
                style={{ width: `${avgScore}%` }}
              />
            </div>
            <p className="text-xs text-gray-400 mt-2">
              {avgScore >= 80
                ? "🎉 You're ready for the real test!"
                : avgScore >= 60
                ? "Getting there! Keep practicing to reach 80%."
                : "Keep practicing! Aim for 80% before your test."}
            </p>
          </div>
        )}

        {/* Quick practice */}
        <div className="mb-8">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Quick Practice</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { href: "/practice?mode=quick", label: "Quick Practice", desc: "10 random questions", icon: Clock, color: "border-blue-200 hover:bg-blue-50" },
              { href: "/practice?mode=signs", label: "Road Signs", desc: "Signs only test", icon: BookOpen, color: "border-purple-200 hover:bg-purple-50" },
              { href: "/practice?mode=full", label: "Full Exam", desc: "Complete simulation", icon: BarChart2, color: "border-green-200 hover:bg-green-50" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`card p-5 border-2 transition-all group flex items-center gap-4 ${item.color}`}
              >
                <item.icon className="w-6 h-6 text-gray-500" />
                <div>
                  <div className="font-semibold text-gray-900">{item.label}</div>
                  <div className="text-xs text-gray-400">{item.desc}</div>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-gray-600 ml-auto" />
              </Link>
            ))}
          </div>
        </div>

        {/* States */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">Practice by State</h2>
            <Link href="/states" className="text-sm text-blue-600 hover:underline">View all →</Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {popularStates.map((state) => (
              <Link
                key={state.code}
                href={`/practice?state=${state.code}`}
                className="card p-4 hover:border-blue-300 hover:bg-blue-50 transition-all flex items-center gap-3"
              >
                <span className="font-extrabold text-blue-600 text-lg w-8">{state.code}</span>
                <div>
                  <div className="text-sm font-semibold text-gray-800">{state.name}</div>
                  <div className="text-xs text-gray-400">{state.questionsCount}q</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent sessions */}
        {sessions.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Recent Tests</h2>
            <div className="card divide-y divide-gray-50">
              {sessions.slice(0, 5).map((ts) => {
                const pct = Math.round((ts.score ?? 0) / ts.totalQ * 100);
                return (
                  <div key={ts.id} className="flex items-center justify-between p-4">
                    <div>
                      <div className="font-medium text-gray-800 text-sm">{ts.state.name} — {ts.mode.replace("_", " ")}</div>
                      <div className="text-xs text-gray-400">{new Date(ts.createdAt).toLocaleDateString()}</div>
                    </div>
                    <span className={`font-bold text-sm ${pct >= 80 ? "text-green-600" : pct >= 60 ? "text-yellow-600" : "text-red-500"}`}>
                      {pct}%
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Upgrade CTA */}
        {!isPremium && (
          <div className="card bg-blue-600 border-0 p-6 text-white flex items-center justify-between gap-4 flex-wrap">
            <div>
              <div className="flex items-center gap-2 font-bold text-lg mb-1">
                <Zap className="w-5 h-5 text-yellow-300" />
                Upgrade to Premium
              </div>
              <p className="text-blue-100 text-sm">
                Unlock all 50 states, unlimited tests, and the full exam simulator for $9/month.
              </p>
            </div>
            <Link
              href="/api/stripe/checkout"
              className="bg-white text-blue-600 font-bold px-5 py-2.5 rounded-xl hover:bg-blue-50 transition-colors text-sm whitespace-nowrap"
            >
              Upgrade Now →
            </Link>
          </div>
        )}
      </main>
    </div>
  );
}
