// src/app/pricing/page.tsx
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CheckCircle, Zap } from "lucide-react";
import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Pricing — Free & Premium DMV Practice Tests",
  description: "Start free with 10 questions. Upgrade to Premium for $9/month to unlock all 50 states, unlimited tests, and the full exam simulator.",
};

const FREE_FEATURES = [
  "Access to 1 state",
  "10 questions per test",
  "Basic answer explanations",
  "Road sign previews",
];

const PREMIUM_FEATURES = [
  "All 50 states",
  "Unlimited practice tests",
  "Full exam simulator",
  "Advanced explanations",
  "Progress tracking & readiness score",
  "Road sign test mode",
  "Priority support",
];

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-14">
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
            Simple, honest pricing
          </h1>
          <p className="text-xl text-gray-500 max-w-xl mx-auto">
            Start free. Upgrade when you're ready. Cancel anytime.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {/* Free */}
          <div className="card p-8 border-2 border-gray-200">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-1">Free</h2>
              <div className="flex items-end gap-1">
                <span className="text-4xl font-extrabold text-gray-900">$0</span>
                <span className="text-gray-500 mb-1">forever</span>
              </div>
            </div>
            <ul className="space-y-3 mb-8">
              {FREE_FEATURES.map((f) => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-gray-600">
                  <CheckCircle className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <Link
              href="/register"
              className="btn-secondary w-full text-center block"
            >
              Get Started Free
            </Link>
          </div>

          {/* Premium */}
          <div className="card p-8 border-2 border-blue-500 relative shadow-xl shadow-blue-100">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2">
              <span className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                <Zap className="w-3 h-3" />
                MOST POPULAR
              </span>
            </div>
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-1">Premium</h2>
              <div className="flex items-end gap-1">
                <span className="text-4xl font-extrabold text-gray-900">$9</span>
                <span className="text-gray-500 mb-1">/month</span>
              </div>
            </div>
            <ul className="space-y-3 mb-8">
              {PREMIUM_FEATURES.map((f) => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-gray-700">
                  <CheckCircle className="w-4 h-4 text-blue-500 flex-shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <Link
              href="/register?plan=premium"
              className="btn-primary w-full text-center block"
            >
              Start Free Trial
            </Link>
          </div>
        </div>

        <div className="mt-10 text-center text-gray-500 text-sm">
          <p>No credit card required for free plan. Cancel premium anytime — no questions asked.</p>
          <p className="mt-1">Questions? <a href="mailto:support@dmvprep.pro" className="text-blue-600 hover:underline">support@dmvprep.pro</a></p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
