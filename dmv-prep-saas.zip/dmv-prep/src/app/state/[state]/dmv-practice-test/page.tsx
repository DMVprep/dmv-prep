// src/app/state/[state]/dmv-practice-test/page.tsx
import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { QuestionPreview } from "@/components/test/QuestionPreview";
import { US_STATES, stateToSlug, getStateBySlug } from "@/data/states";
import { SAMPLE_QUESTIONS, DMV_VOCABULARY } from "@/data/questions";
import { CheckCircle, Clock, BookOpen, ArrowRight, AlertCircle } from "lucide-react";

interface Props {
  params: { state: string };
}

export async function generateStaticParams() {
  return US_STATES.map((s) => ({ state: stateToSlug(s.name) }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const state = getStateBySlug(params.state);
  if (!state) return {};
  return {
    title: `${state.name} DMV Practice Test 2024 — Free Permit Test Questions`,
    description: `Free ${state.name} DMV practice test with real permit test questions. Plain-English explanations. Pass your ${state.name} written test on the first try. ${state.questionsCount} questions, ${state.passingScore}% passing score.`,
    keywords: [
      `${state.name} DMV practice test`,
      `${state.name} permit test`,
      `${state.code} DMV test`,
      `${state.name} driving test questions`,
    ],
  };
}

const STATE_TIPS: Record<string, string[]> = {
  default: [
    "Read each question carefully before answering",
    "If unsure, eliminate obviously wrong answers first",
    "Practice at least 3 full tests before your real exam",
    "Pay extra attention to road signs — they are heavily tested",
    "Get a good night's sleep before your test day",
  ],
};

const PAGE_LINKS = [
  { href: "road-sign-practice-test", label: "Road Sign Practice Test" },
  { href: "permit-test-questions", label: "Permit Test Questions" },
  { href: "dmv-handbook-summary", label: "DMV Handbook Summary" },
  { href: "dmv-test-tips", label: "Test Tips & Guide" },
];

export default function StatePracticeTestPage({ params }: Props) {
  const state = getStateBySlug(params.state);
  if (!state) notFound();

  const allQuestions = SAMPLE_QUESTIONS.flatMap((t) => t.questions).slice(0, 5);
  const tips = STATE_TIPS[state.code] ?? STATE_TIPS.default;

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main>
        {/* Hero */}
        <section className="bg-gradient-to-b from-blue-50 to-white py-14 px-4 border-b border-gray-100">
          <div className="max-w-4xl mx-auto text-center">
            <div className="text-sm text-blue-600 font-medium mb-3 uppercase tracking-wide">
              {state.name} DMV Practice Test 2024
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-5">
              {state.name} DMV<br />Practice Test
            </h1>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto mb-8">
              Practice real {state.name} DMV knowledge test questions with simple, clear
              explanations. This test is free and covers the same topics as the official
              {state.name} written permit exam.
            </p>

            <div className="flex flex-wrap justify-center gap-4 mb-8 text-sm">
              {[
                { icon: BookOpen, label: `${state.questionsCount} total questions` },
                { icon: CheckCircle, label: `${state.passingScore}% to pass` },
                { icon: Clock, label: "~30 minutes" },
              ].map(({ icon: Icon, label }) => (
                <span key={label} className="flex items-center gap-1.5 bg-white border border-gray-200 px-3 py-1.5 rounded-full text-gray-600 shadow-sm">
                  <Icon className="w-4 h-4 text-blue-500" />
                  {label}
                </span>
              ))}
            </div>

            <Link
              href={`/practice?state=${state.code}`}
              className="btn-primary text-lg py-4 px-10 inline-flex items-center gap-2"
            >
              Start Full Practice Test
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </section>

        {/* Sub-page nav */}
        <section className="bg-white border-b border-gray-100 px-4 py-3 overflow-x-auto">
          <div className="max-w-4xl mx-auto flex gap-2 min-w-max">
            <span className="bg-blue-600 text-white text-xs font-semibold px-3 py-1.5 rounded-full">
              Practice Test
            </span>
            {PAGE_LINKS.map((link) => (
              <Link
                key={link.href}
                href={`/state/${params.state}/${link.href}`}
                className="bg-gray-100 hover:bg-blue-50 hover:text-blue-600 text-gray-600 text-xs font-medium px-3 py-1.5 rounded-full transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </section>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
          {/* Sample questions */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Sample {state.name} DMV Questions
            </h2>
            <p className="text-gray-500 mb-6">
              Try these 5 free questions. Sign up to access all {state.questionsCount} practice
              questions and the full exam simulator.
            </p>
            <div className="space-y-4">
              {allQuestions.map((q, i) => (
                <QuestionPreview key={i} question={q} index={i} />
              ))}
            </div>
            <div className="mt-8 text-center">
              <Link
                href={`/practice?state=${state.code}`}
                className="btn-primary inline-flex items-center gap-2 text-lg py-4 px-8"
              >
                Practice All {state.questionsCount} Questions Free
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </section>

          {/* About the test */}
          <section className="mb-12 card p-8 bg-blue-50 border-blue-100">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              About the {state.name} DMV Knowledge Test
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
              {[
                { label: "Total Questions", value: `${state.questionsCount} questions` },
                { label: "Passing Score", value: `${state.passingScore}% (${Math.ceil(state.questionsCount * state.passingScore / 100)} correct)` },
                { label: "Test Format", value: "Multiple choice" },
                { label: "Retake Policy", value: "Wait period if failed" },
              ].map(({ label, value }) => (
                <div key={label}>
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</div>
                  <div className="font-semibold text-gray-800">{value}</div>
                </div>
              ))}
            </div>
            <p className="text-gray-600 text-sm leading-relaxed">
              The {state.name} DMV written knowledge test covers traffic laws, road signs, safe
              driving practices, and state-specific rules. You must score at least {state.passingScore}%
              to pass. The test is taken at your local {state.name} DMV office.
            </p>
          </section>

          {/* Test tips */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Tips to Pass the {state.name} DMV Test
            </h2>
            <ul className="space-y-3">
              {tips.map((tip, i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{tip}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* DMV Vocabulary */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">DMV Vocabulary Guide</h2>
            <p className="text-gray-500 mb-6 text-sm">
              Important words you will see on the {state.name} DMV test — explained in simple English.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {DMV_VOCABULARY.slice(0, 6).map((v) => (
                <div key={v.term} className="card p-4">
                  <div className="font-bold text-blue-600 mb-1">{v.term}</div>
                  <div className="text-sm text-gray-600 leading-relaxed">{v.definition}</div>
                </div>
              ))}
            </div>
          </section>

          {/* CTA */}
          <section className="card bg-blue-600 border-0 p-8 text-center text-white">
            <AlertCircle className="w-10 h-10 mx-auto mb-3 text-blue-200" />
            <h3 className="text-2xl font-bold mb-2">Ready to practice all {state.questionsCount} questions?</h3>
            <p className="text-blue-100 mb-6">
              Create a free account to track your progress, unlock all questions, and use the full
              exam simulator.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link href="/register" className="inline-flex items-center justify-center gap-2 bg-white text-blue-600 font-bold py-3 px-6 rounded-xl hover:bg-blue-50 transition-colors">
                Create Free Account
              </Link>
              <Link href={`/practice?state=${state.code}`} className="inline-flex items-center justify-center gap-2 bg-blue-500 text-white font-bold py-3 px-6 rounded-xl hover:bg-blue-400 transition-colors">
                Start Without Account
              </Link>
            </div>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
}
