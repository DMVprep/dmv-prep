// src/app/api/questions/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { shuffle } from "@/lib/utils";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const stateCode = searchParams.get("state") || "CA";
  const mode = searchParams.get("mode") || "quick";
  const topic = searchParams.get("topic");

  const session = await getServerSession(authOptions);
  const isPremium = (session?.user as any)?.plan === "PREMIUM";

  const state = await prisma.state.findUnique({ where: { code: stateCode.toUpperCase() } });
  if (!state) return NextResponse.json({ error: "State not found" }, { status: 404 });

  const where: any = { stateId: state.id };
  if (topic) where.topicId = topic;
  if (mode === "signs") {
    const signTopic = await prisma.topic.findUnique({ where: { slug: "traffic-signs" } });
    if (signTopic) where.topicId = signTopic.id;
  }

  const questions = await prisma.question.findMany({
    where,
    include: { choices: true, topic: true },
    take: 100,
  });

  const shuffled = shuffle(questions);
  const limit = isPremium ? (mode === "full" ? shuffled.length : 20) : 10;
  const sliced = shuffled.slice(0, limit);

  return NextResponse.json({ questions: sliced });
}
