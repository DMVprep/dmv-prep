// src/app/page.tsx
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { US_STATES, stateToSlug } from "@/data/states";
import {
  CheckCircle, Star, BookOpen, Brain, Trophy, Clock,
  Globe, Users, ArrowRight, Shield
} from "lucide-react";

const TESTIMONIALS = [
  {
    name: "Maria G.",
    from: "Originally from Mexico",
    quote: "I failed the DMV test twice before. The simple explanations on this site finally made everything clear. I passed on my first try with 92%!",
    stars: 5,
  },
  {
    name: "David K.",
    from: "Moved from Ohio to Florida",
    quote: "Moving states meant learning all new rules. This site's Florida-specific practice tests saved me hours of reading the handbook.",
    stars: 5,
  },
  {
    name: "Sarah L.",
    from: "First-time driver at 34",
    quote: "I was nervous about taking the test as an adult. The readiness score feature showed me exactly when I was ready. Passed first try!",
    stars: 5,
  },
];

const FEATURES = [
  {
    icon: BookOpen,
    title: "Plain-English Explanations",
    description: "Every answer is explained in simple words — no confusing legal language. Perfect for non-native English speakers.",
    color: "text-blue-600 bg-blue-50",
  },
  {
    icon: Brain,
    title: "Smart Practice Tests",
    description: "Questions randomly shuffle every time. Learn from mistakes with instant explanations after each answer.",
    color: "text-purple-600 bg-purple-50",
  },
  {
    icon: Trophy,
    title: "Readiness Score",
    description: "Our algorithm estimates your real probability of passing. Know exactly when you're ready — before you visit the DMV.",
    color: "text-yellow-600 bg-yellow-50",
  },
  {
    icon: Globe,
    title: "All 50 States",
    description: "Each state has different questions and rules. We cover every state with state-specific questions and handbook summaries.",
    color: "text-green-600 bg-green-50",
  },
  {
    icon: Clock,
    title: "Exam Simulator",
    description: "Practice under real test conditions with a timer. Know exactly what to expect on test day.",
    color: "text-red-600 bg-red-50",
  },
  {
    icon: Shield,
    title: "Road Sign Tests",
    description: "Dedicated road sign practice with visual explanations. Master every sign you'll see on the test.",
    color: "text-indigo-600 bg-indigo-50",
  },
];

const POPULAR_STATES = US_STATES.filter(s =>
  ["CA", "TX", "FL", "NY", "IL", "PA", "OH", "GA", "NC", "MI"].includes(s.code)
);

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero */}
      <section className="relative bg-gradient-to-b from-blue-50 to-white pt-16 pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(59,130,246,0.1),transparent)]" />
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 text-sm font-medium px-4 py-1.5 rounded-full mb-6">
            <Users className="w-4 h-4" />
            <span>Trusted by 500,000+ drivers across the US</span>
          </div>

          <h1 className="text-5xl md:text-6xl font-extrabold text-gray-900 tracking-tight mb-6">
            Pass Your DMV Test<br />
            <span className="text-blue-600">on the First Try</span>
          </h1>

          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed">
            Practice real DMV questions with simple, clear explanations. Designed for{" "}
            <strong>immigrants</strong>, <strong>first-time drivers</strong>, and anyone who wants
            to stop reading the handbook and start <em>actually learning</em>.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/states" className="btn-primary text-lg py-4 px-8 inline-flex items-center gap-2">
              Start Free Practice Test
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/pricing" className="btn-secondary text-lg py-4 px-8">
              View Pricing
            </Link>
          </div>

          <div className="flex items-center justify-center gap-8 text-sm text-gray-500">
            {["No credit card required", "All 50 states", "Free to start"].map((item) => (
              <span key={item} className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-green-500" />
                {item}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="bg-blue-600 py-8">
        <div className="max-w-5xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6 text-center text-white">
          {[
            { num: "500K+", label: "Tests Taken" },
            { num: "50", label: "States Covered" },
            { num: "87%", label: "Pass Rate" },
            { num: "10,000+", label: "Practice Questions" },
          ].map(({ num, label }) => (
            <div key={label}>
              <div className="text-3xl font-extrabold">{num}</div>
              <div className="text-blue-200 text-sm mt-1">{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything you need to pass
            </h2>
            <p className="text-gray-500 text-lg max-w-xl mx-auto">
              We replaced the boring DMV handbook with a smarter, friendlier learning experience.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((f) => (
              <div key={f.title} className="card p-6">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${f.color}`}>
                  <f.icon className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-gray-900 text-lg mb-2">{f.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{f.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular States */}
      <section className="py-16 bg-gray-50 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Popular State Practice Tests</h2>
            <p className="text-gray-500">Click your state to start a free practice test right now.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {POPULAR_STATES.map((state) => (
              <Link
                key={state.code}
                href={`/state/${stateToSlug(state.name)}/dmv-practice-test`}
                className="card p-4 text-center hover:border-blue-200 hover:bg-blue-50 transition-all group"
              >
                <div className="text-2xl font-extrabold text-blue-600 group-hover:text-blue-700">{state.code}</div>
                <div className="text-xs text-gray-600 mt-1 font-medium">{state.name}</div>
                <div className="text-xs text-gray-400 mt-0.5">{state.questionsCount} questions</div>
              </Link>
            ))}
          </div>
          <div className="text-center mt-6">
            <Link href="/states" className="text-blue-600 font-medium hover:underline text-sm inline-flex items-center gap-1">
              See all 50 states <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Real people, real results</h2>
            <p className="text-gray-500">Join hundreds of thousands who passed with DMVPrep Pro</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="card p-6">
                <div className="flex gap-0.5 mb-3">
                  {[...Array(t.stars)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 text-sm leading-relaxed mb-4">"{t.quote}"</p>
                <div>
                  <div className="font-semibold text-gray-900 text-sm">{t.name}</div>
                  <div className="text-gray-400 text-xs">{t.from}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-blue-600 py-16 px-4">
        <div className="max-w-3xl mx-auto text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to pass your DMV test?
          </h2>
          <p className="text-blue-100 text-lg mb-8">
            Start practicing for free today. No account required to try your first test.
          </p>
          <Link href="/states" className="inline-flex items-center gap-2 bg-white text-blue-600 font-bold py-4 px-8 rounded-xl hover:bg-blue-50 transition-colors text-lg shadow-lg">
            Start Practice Test Now
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
