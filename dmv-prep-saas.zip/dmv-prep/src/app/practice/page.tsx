// src/app/practice/page.tsx
"use client";
import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Header } from "@/components/layout/Header";
import { SAMPLE_QUESTIONS } from "@/data/questions";
import { US_STATES } from "@/data/states";
import { shuffle, cn } from "@/lib/utils";
import {
  CheckCircle, XCircle, ChevronRight, RotateCcw,
  Trophy, Clock, Target, BookOpen
} from "lucide-react";
import Link from "next/link";

type Mode = "select" | "test" | "results";

interface FlatQuestion {
  text: string;
  choices: string[];
  correct: number;
  explanation: string;
  topic: string;
}

function PracticeContent() {
  const searchParams = useSearchParams();
  const stateCode = searchParams.get("state") || "CA";
  const state = US_STATES.find(s => s.code === stateCode) || US_STATES[4];

  const [mode, setMode] = useState<Mode>("select");
  const [questions, setQuestions] = useState<FlatQuestion[]>([]);
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answers, setAnswers] = useState<boolean[]>([]);
  const [timer, setTimer] = useState(0);
  const [testMode, setTestMode] = useState<"quick" | "full" | "signs">("quick");

  useEffect(() => {
    if (mode !== "test") return;
    const interval = setInterval(() => setTimer((t) => t + 1), 1000);
    return () => clearInterval(interval);
  }, [mode]);

  const startTest = (selectedMode: typeof testMode) => {
    setTestMode(selectedMode);
    const flat: FlatQuestion[] = SAMPLE_QUESTIONS.flatMap((t) =>
      t.questions.map((q) => ({ ...q, topic: t.topic }))
    );
    const filtered = selectedMode === "signs"
      ? flat.filter((q) => q.topic === "traffic-signs")
      : flat;
    const count = selectedMode === "full" ? flat.length : Math.min(10, filtered.length);
    setQuestions(shuffle(filtered).slice(0, count));
    setCurrent(0);
    setSelected(null);
    setAnswers([]);
    setTimer(0);
    setMode("test");
  };

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
  };

  const nextQuestion = () => {
    if (selected === null) return;
    const isCorrect = selected === questions[current].correct;
    const newAnswers = [...answers, isCorrect];
    setAnswers(newAnswers);
    if (current + 1 >= questions.length) {
      setMode("results");
    } else {
      setCurrent((c) => c + 1);
      setSelected(null);
    }
  };

  const formatTime = (s: number) =>
    `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  const score = answers.filter(Boolean).length;
  const pct = questions.length ? Math.round((score / questions.length) * 100) : 0;
  const passed = pct >= state.passingScore;

  if (mode === "select") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-2xl mx-auto px-4 py-12">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-extrabold text-gray-900 mb-2">
              {state.name} DMV Practice Test
            </h1>
            <p className="text-gray-500">Choose a test mode to begin</p>
          </div>
          <div className="space-y-4">
            {[
              {
                id: "quick" as const,
                icon: Clock,
                title: "Quick Practice",
                desc: "10 random questions — great for daily review",
                time: "~5 min",
                color: "border-blue-200 hover:border-blue-400",
                iconColor: "text-blue-600 bg-blue-50",
              },
              {
                id: "signs" as const,
                icon: BookOpen,
                title: "Road Sign Test",
                desc: "Practice only road sign questions",
                time: "~3 min",
                color: "border-purple-200 hover:border-purple-400",
                iconColor: "text-purple-600 bg-purple-50",
              },
              {
                id: "full" as const,
                icon: Target,
                title: "Full Exam Simulation",
                desc: `${SAMPLE_QUESTIONS.flatMap(t => t.questions).length} questions under real exam conditions`,
                time: "~20 min",
                color: "border-green-200 hover:border-green-400",
                iconColor: "text-green-600 bg-green-50",
              },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => startTest(m.id)}
                className={cn(
                  "w-full card p-5 text-left border-2 transition-all group flex items-center gap-4",
                  m.color
                )}
              >
                <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0", m.iconColor)}>
                  <m.icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-gray-900 text-lg">{m.title}</div>
                  <div className="text-gray-500 text-sm">{m.desc}</div>
                </div>
                <div className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-full">
                  {m.time}
                </div>
              </button>
            ))}
          </div>

          <div className="mt-8 card p-4 bg-blue-50 border-blue-100">
            <p className="text-sm text-blue-700">
              <strong>Free plan:</strong> 10 questions per test.{" "}
              <Link href="/pricing" className="underline font-semibold">Upgrade to Premium</Link>
              {" "}for unlimited tests, all states, and the full exam simulator.
            </p>
          </div>
        </main>
      </div>
    );
  }

  if (mode === "results") {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="max-w-lg w-full card p-8 text-center">
          <div className={cn(
            "w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6",
            passed ? "bg-green-100" : "bg-orange-100"
          )}>
            {passed
              ? <Trophy className="w-12 h-12 text-green-600" />
              : <RotateCcw className="w-12 h-12 text-orange-600" />
            }
          </div>

          <h2 className="text-3xl font-extrabold text-gray-900 mb-1">
            {passed ? "You Passed! 🎉" : "Keep Practicing!"}
          </h2>
          <p className="text-gray-500 mb-6">
            {passed
              ? `Great job! You scored ${pct}% — above the ${state.passingScore}% passing mark.`
              : `You scored ${pct}%. You need ${state.passingScore}% to pass. Try again!`
            }
          </p>

          <div className="grid grid-cols-3 gap-4 mb-8">
            {[
              { label: "Score", value: `${pct}%` },
              { label: "Correct", value: `${score}/${questions.length}` },
              { label: "Time", value: formatTime(timer) },
            ].map(({ label, value }) => (
              <div key={label} className="bg-gray-50 rounded-xl p-3">
                <div className="font-extrabold text-2xl text-gray-900">{value}</div>
                <div className="text-xs text-gray-400 mt-0.5">{label}</div>
              </div>
            ))}
          </div>

          {/* Per-question review */}
          <div className="text-left space-y-2 mb-8 max-h-48 overflow-y-auto">
            {questions.map((q, i) => (
              <div key={i} className={cn(
                "flex items-start gap-2 p-3 rounded-lg text-sm",
                answers[i] ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"
              )}>
                {answers[i]
                  ? <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  : <XCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                }
                <span className="font-medium">{q.text.slice(0, 60)}...</span>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => { setMode("select"); }}
              className="btn-secondary flex-1"
            >
              Try Another Test
            </button>
            <Link href="/register" className="btn-primary flex-1 text-center">
              Save My Progress
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Test mode
  const q = questions[current];
  const progress = ((current) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="max-w-2xl mx-auto px-4 py-8">
        {/* Progress */}
        <div className="flex items-center justify-between mb-3 text-sm text-gray-500">
          <span>Question {current + 1} of {questions.length}</span>
          <span className="flex items-center gap-1.5">
            <Clock className="w-4 h-4" />
            {formatTime(timer)}
          </span>
        </div>
        <div className="h-2 bg-gray-200 rounded-full mb-8">
          <div
            className="h-2 bg-blue-500 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Question */}
        <div className="card p-6 mb-4">
          <p className="text-xl font-semibold text-gray-900 leading-relaxed">{q.text}</p>
        </div>

        {/* Choices */}
        <div className="space-y-3 mb-6">
          {q.choices.map((choice, i) => (
            <button
              key={i}
              onClick={() => handleAnswer(i)}
              disabled={selected !== null}
              className={cn(
                "w-full text-left px-5 py-4 rounded-xl border-2 font-medium transition-all text-base",
                selected === null && "border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50 text-gray-800",
                selected !== null && i === q.correct && "border-green-400 bg-green-50 text-green-800",
                selected !== null && i === selected && i !== q.correct && "border-red-400 bg-red-50 text-red-700",
                selected !== null && i !== q.correct && i !== selected && "border-gray-100 bg-gray-50 text-gray-400"
              )}
            >
              <span className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-full border-2 border-current flex items-center justify-center text-xs font-bold flex-shrink-0">
                  {String.fromCharCode(65 + i)}
                </span>
                {choice}
                {selected !== null && i === q.correct && <CheckCircle className="w-5 h-5 text-green-500 ml-auto flex-shrink-0" />}
                {selected !== null && i === selected && i !== q.correct && <XCircle className="w-5 h-5 text-red-500 ml-auto flex-shrink-0" />}
              </span>
            </button>
          ))}
        </div>

        {/* Explanation */}
        {selected !== null && (
          <div className={cn(
            "card p-5 mb-6 border-2",
            selected === q.correct ? "border-green-200 bg-green-50" : "border-orange-200 bg-orange-50"
          )}>
            <div className={cn(
              "font-bold mb-1",
              selected === q.correct ? "text-green-700" : "text-orange-700"
            )}>
              {selected === q.correct ? "✓ Correct!" : "✗ Incorrect"}
            </div>
            <p className={cn(
              "text-sm leading-relaxed",
              selected === q.correct ? "text-green-700" : "text-orange-700"
            )}>
              {q.explanation}
            </p>
          </div>
        )}

        <button
          onClick={nextQuestion}
          disabled={selected === null}
          className={cn(
            "w-full btn-primary flex items-center justify-center gap-2 text-lg py-4",
            selected === null && "opacity-40 cursor-not-allowed"
          )}
        >
          {current + 1 >= questions.length ? "See Results" : "Next Question"}
          <ChevronRight className="w-5 h-5" />
        </button>
      </main>
    </div>
  );
}

export default function PracticePage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-gray-50 flex items-center justify-center"><div className="text-gray-400">Loading...</div></div>}>
      <PracticeContent />
    </Suspense>
  );
}
