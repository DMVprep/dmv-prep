// src/app/layout.tsx
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/layout/Providers";
import { Toaster } from "react-hot-toast";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: {
    default: "DMV Practice Test 2024 — Pass Your Permit Test First Try",
    template: "%s | DMV Prep Pro",
  },
  description:
    "Free DMV practice tests for all 50 states. Plain-English explanations, road sign tests, and exam simulators. Designed for immigrants, adults, and first-time drivers.",
  keywords: ["DMV practice test", "permit test", "driving test", "road signs", "DMV handbook"],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://dmvprep.pro",
    siteName: "DMV Prep Pro",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          {children}
          <Toaster position="top-right" />
        </Providers>
      </body>
    </html>
  );
}
