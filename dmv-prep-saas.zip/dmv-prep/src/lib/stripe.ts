// src/lib/stripe.ts
import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-04-10",
});

export const PLANS = {
  FREE: {
    name: "Free",
    price: 0,
    features: [
      "1 state access",
      "10 questions per test",
      "Basic explanations",
    ],
  },
  PREMIUM: {
    name: "Premium",
    price: 9,
    priceId: process.env.STRIPE_PREMIUM_PRICE_ID!,
    features: [
      "All 50 states",
      "Unlimited practice tests",
      "Full exam simulator",
      "Advanced explanations",
      "Progress tracking",
      "Road sign tests",
    ],
  },
};
